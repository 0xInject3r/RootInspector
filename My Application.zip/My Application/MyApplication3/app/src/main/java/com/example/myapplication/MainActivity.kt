package com.example.myapplication

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RootDetectionApp()
        }
    }
}

@Composable
fun RootDetectionApp() {
    MaterialTheme {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            RootDetectionScreen()
        }
    }
}

@Composable
fun RootDetectionScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var detectionResult by remember { mutableStateOf<RootDetection.DetectionResult?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val exceptionHandler = CoroutineExceptionHandler { _, throwable ->
        errorMessage = "Detection failed: ${throwable.message}"
        isLoading = false
    }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO + exceptionHandler) {
            detectionResult = RootDetection.detectAll(context as ComponentActivity)
            isLoading = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (isLoading) {
            CircularProgressIndicator()
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Scanning device for security threats...",
                fontSize = 18.sp,
                fontWeight = FontWeight.Medium
            )
        } else if (errorMessage != null) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Error",
                        style = MaterialTheme.typography.headlineSmall,
                        color = Color(0xFFC62828),
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = errorMessage ?: "Unknown error during detection",
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            }
        } else {
            detectionResult?.let { result ->
                DetectionResultView(result)
            }
        }
    }
}

@Composable
fun DetectionResultView(result: RootDetection.DetectionResult) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Security Scan Results",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Text(
            text = "Device Integrity Check",
            style = MaterialTheme.typography.titleMedium,
            color = Color(0xFF616161),
            modifier = Modifier.padding(bottom = 16.dp)
        )

        SecurityStatusCard(result.isRooted)

        Spacer(modifier = Modifier.height(24.dp))

        DetectionSummarySection(result)

        // Show details if any detection method has results
        if (result.isRooted || result.rootPackages.isNotEmpty() || result.rootPaths.isNotEmpty() ||
            result.magiskIndicators.isNotEmpty() || result.zygiskIndicators.isNotEmpty() ||
            result.lsposedIndicators.isNotEmpty() || result.riruIndicators.isNotEmpty() ||
            result.shamikoIndicators.isNotEmpty() || result.xposedIndicators.isNotEmpty() ||
            result.fridaIndicators.isNotEmpty() || result.busyboxIndicators.isNotEmpty() ||
            result.suBehavior != null || result.dangerousProps.isNotEmpty() ||
            result.tamperIndicators.isNotEmpty()
        ) {
            DetectionDetailsSection(result)
        }

        // Show debug info only in debug builds
        if (BuildConfig.DEBUG) {
            Spacer(modifier = Modifier.height(24.dp))
            DebugInfoSection(result)
        }
    }
}

@Composable
fun SecurityStatusCard(isRooted: Boolean) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (isRooted) Color(0xFFFFEBEE) else Color(0xFFE8F5E9)
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = if (isRooted) "DEVICE COMPROMISED" else "DEVICE SECURE",
                style = MaterialTheme.typography.headlineSmall,
                color = if (isRooted) Color(0xFFC62828) else Color(0xFF2E7D32),
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = if (isRooted) "Root access or tampering detected" else "No root access or tampering found",
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
}

@Composable
fun DetectionSummarySection(result: RootDetection.DetectionResult) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F5F5))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = "Detection Summary",
                style = MaterialTheme.typography.titleMedium,
                color = Color(0xFF424242)
            )
            Text(
                text = "Overview of security checks performed",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF616161),
                modifier = Modifier.padding(bottom = 8.dp)
            )
            DetectionSummaryItem("Root Paths", result.rootPaths.isNotEmpty())
            DetectionSummaryItem("Root Packages", result.rootPackages.isNotEmpty())
            DetectionSummaryItem("Magisk Indicators", result.magiskIndicators.isNotEmpty())
            DetectionSummaryItem("Zygisk Traces", result.zygiskIndicators.isNotEmpty())
            DetectionSummaryItem("LSPosed Indicators", result.lsposedIndicators.isNotEmpty())
            DetectionSummaryItem("Riru Indicators", result.riruIndicators.isNotEmpty())
            DetectionSummaryItem("Shamiko Indicators", result.shamikoIndicators.isNotEmpty())
            DetectionSummaryItem("Xposed Framework", result.xposedIndicators.isNotEmpty())
            DetectionSummaryItem("Frida Debugger", result.fridaIndicators.isNotEmpty())
            DetectionSummaryItem("Busybox Indicators", result.busyboxIndicators.isNotEmpty())
            DetectionSummaryItem("SU Behavior", result.suBehavior != null)
            DetectionSummaryItem("Dangerous Props", result.dangerousProps.isNotEmpty())
            DetectionSummaryItem("Tamper Evidence", result.tamperIndicators.isNotEmpty())

            // Warn about possible permission issues for LSPosed
            if (result.lsposedIndicators.any { it.contains("Access denied") }) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Warning: Some LSPosed paths could not be accessed. Detection may be incomplete.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFD84315)
                )
            }
        }
    }
}

@Composable
fun DetectionSummaryItem(title: String, isDetected: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.bodyMedium
        )
        Text(
            text = if (isDetected) "Detected" else "Not Detected",
            style = MaterialTheme.typography.bodyMedium,
            color = if (isDetected) Color(0xFFC62828) else Color(0xFF2E7D32)
        )
    }
}

@Composable
fun DetectionDetailsSection(result: RootDetection.DetectionResult) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.Start
    ) {
        Text(
            text = "Detection Details",
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        result.rootPaths.takeIf { it.isNotEmpty() }?.let {
            DetectionDetailItem("Root Paths Found:", it)
        }

        result.rootPackages.takeIf { it.isNotEmpty() }?.let {
            DetectionDetailItem("Root Packages:", it)
        }

        result.magiskIndicators.takeIf { it.isNotEmpty() }?.let {
            DetectionDetailItem("Magisk Indicators:", it)
        }

        result.zygiskIndicators.takeIf { it.isNotEmpty() }?.let {
            DetectionDetailItem("Zygisk Traces:", it)
        }

        result.lsposedIndicators.takeIf { it.isNotEmpty() }?.let {
            DetectionDetailItem("LSPosed Indicators:", it)
        }

        result.riruIndicators.takeIf { it.isNotEmpty() }?.let {
            DetectionDetailItem("Riru Indicators:", it)
        }

        result.shamikoIndicators.takeIf { it.isNotEmpty() }?.let {
            DetectionDetailItem("Shamiko Indicators:", it)
        }

        result.xposedIndicators.takeIf { it.isNotEmpty() }?.let {
            DetectionDetailItem("Xposed Framework:", it)
        }

        result.fridaIndicators.takeIf { it.isNotEmpty() }?.let {
            DetectionDetailItem("Frida Debugger:", it)
        }

        result.busyboxIndicators.takeIf { it.isNotEmpty() }?.let {
            DetectionDetailItem("Busybox Indicators:", it)
        }

        result.suBehavior?.let {
            DetectionDetailItem("SU Behavior:", listOf(it))
        }

        result.dangerousProps.takeIf { it.isNotEmpty() }?.let {
            DetectionDetailItem("Dangerous Props:", it.map { "${it.key}=${it.value}" })
        }

        result.tamperIndicators.takeIf { it.isNotEmpty() }?.let {
            DetectionDetailItem("Tamper Evidence:", it)
        }
    }
}

@Composable
fun DetectionDetailItem(title: String, items: List<String>) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F5F5))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = Color(0xFF424242)
            )
            Spacer(modifier = Modifier.height(4.dp))
            items.forEach { item ->
                Text(
                    text = "• $item",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(start = 8.dp, bottom = 2.dp)
                )
            }
        }
    }
}

@Composable
fun DebugInfoSection(result: RootDetection.DetectionResult) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFE0F7FA))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = "Debug Information",
                style = MaterialTheme.typography.titleMedium,
                color = Color(0xFF006064)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Raw LSPosed Indicators: ${result.lsposedIndicators.joinToString(", ") { "\"$it\"" }}",
                style = MaterialTheme.typography.bodySmall
            )
            Text(
                text = "Raw Root Packages: ${result.rootPackages.joinToString(", ") { "\"$it\"" }}",
                style = MaterialTheme.typography.bodySmall
            )
            Text(
                text = "Detection Methods: ${result.detectionMethods.joinToString(", ")}",
                style = MaterialTheme.typography.bodySmall
            )
            Text(
                text = "Shamiko Indicators: ${result.shamikoIndicators.joinToString(", ")}",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}