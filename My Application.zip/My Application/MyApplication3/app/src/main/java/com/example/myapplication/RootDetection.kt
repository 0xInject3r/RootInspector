package com.example.myapplication

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.TimeUnit

object RootDetection {
    private const val TAG = "RootDetection"
    private const val TIMEOUT_MS = 1500

    // Updated 2025 root detection paths
    private val ROOT_PATHS = listOf(
        "/system/bin/su", "/system/xbin/su", "/sbin/su", "/system/su",
        "/system/bin/.ext/.su", "/system/usr/we-need-root/su",
        "/data/local/tmp/su", "/data/local/bin/su", "/data/local/xbin/su",
        "/vendor/bin/su", "/su/bin/su", "/magisk/.core/bin/su",
        "/system/bin/magisk", "/system/xbin/magisk",
        "/system/bin/.magisk", "/system/xbin/.magisk",
        "/data/adb/magisk", "/data/adb/modules/*/system/xbin/su",
        "/system/app/SuperSU", "/system/app/Superuser",
        "/system/app/Magisk", "/system/app/KingRoot",
        "/system/priv-app/SuperSU", "/system/priv-app/Superuser", "/system/priv-app/Magisk",
        "/system/su", "/data/local/userinit.sh", "/data/local/customboot.sh",
        "/data/local/post-fs-data.sh", "/data/local/service.sh"
    )

    // Updated 2025 root packages
    private val ROOT_PACKAGES = listOf(
        "com.topjohnwu.magisk", "io.github.vvb2060.magisk",
        "eu.chainfire.supersu", "com.koushikdutta.superuser",
        "com.kingroot.kinguser", "com.kingo.root",
        "com.smedialink.oneclickroot", "com.zachspong.temprootremovejb",
        "com.ramdroid.appquarantine", "org.lsposed.manager",
        "com.devadvance.rootcloak", "com.devadvance.rootcloakplus",
        "com.formyhm.hideroot", "de.robv.android.xposed.installer",
        "org.meowcat.edxposed.manager", "io.github.huskydg.magisk",
        "com.dimonvideo.luckypatcher", "com.android.vending.billing.InAppBillingService.COIN",
        "com.noshufou.android.su", "com.thirdparty.superuser", "me.phh.superuser",
        "com.koushikdutta.rommanager", "jackpal.androidterm"
    )

    // Magisk specific indicators (extended)
    private val MAGISK_PATHS = listOf(
        "/sbin/.magisk", "/sbin/magisk", "/cache/.disable_magisk",
        "/cache/magisk.log", "/data/adb/magisk", "/data/adb/modules",
        "/data/adb/post-fs-data.d", "/data/adb/service.d",
        "/data/magisk", "/data/magisk.img", "/data/magisk_merge.img",
        "/sbin/.core/mirror/", "/sbin/.magisk/mirror/",
        "/sbin/.magisk/modules/zygisk/", "/sbin/.magisk/modules/riru/",
        "/sbin/.magisk/modules/lsposed/", "/sbin/.magisk/modules/",
        "/dev/.magisk_unblock", "/dev/magisk", "/dev/magisk/mirror/",
        "/metadata/magisk", "/init.magisk.rc", "/init.magisk.post-fs-data.rc",
        "/init.magisk.service.rc", "/system/etc/init/magisk.rc",
        "/system/bin/.magisk/", "/system/bin/magiskpolicy",
        "/system/xbin/magiskhide", "/vendor/bin/magisk",
        "/data/adb/magisk/configs/", "/data/adb/magisk/db/",
        "/data/adb/magisk/mirror/", "/data/adb/magisk/tmp/",
        "/data/adb/magisk/zygisk/", "/data/adb/magisk/zygisk.cfg",
        "/data/adb/modules_update/", "/data/adb/runtime.d/",
        "/data/unencrypted/magisk/", "/cache/magisk_debug.log"
    )

    // Zygisk traces
    private val ZYGISK_PATHS = listOf(
        "/dev/zygisk/", "/dev/zygisk.rc", "/init.rc",
        "/proc/self/maps", "/proc/self/mountinfo", "/proc/self/status",
        "/proc/*/maps", "/proc/*/mounts",
        "/data/adb/zygisk/", "/data/adb/zygisk/modules/",
        "/data/adb/zygisk/log/", "/data/adb/zygisk/zygisk.rc"
    )

    // LSPosed deep paths
    private val LSPOSED_PATHS = listOf(
        "/data/adb/lspd/", "/data/system/lsposed/", "/data/system/lsposed/log/",
        "/data/system/lsposed/config/", "/data/system/lsposed/config/repo.yml",
        "/data/system/lsposed/modules/", "/data/data/org.lsposed.manager/",
        "/data/app/org.lsposed.manager-*/base.apk",
        "/data/user_de/0/org.lsposed.manager/",
        "/storage/emulated/0/Android/data/org.lsposed.manager/",
        "/data/misc/lsposed/"
    )

    // Riru and hidden Riru paths
    private val RIRU_PATHS = listOf(
        "/data/adb/riru/", "/data/adb/riru/api_version", "/data/adb/riru/modules/",
        "/system/lib/libmemtrack_real.so", "/system/lib64/libmemtrack_real.so",
        "/system/lib/libnb.so", "/system/lib64/libnb.so", "/system/bin/rirud"
    )

    // Shamiko paths
    private val SHAMIKO_PATHS = listOf(
        "/data/adb/modules/shamiko/", "/data/adb/modules_update/shamiko/",
        "/data/adb/shamiko/", "/data/adb/magisk/magiskhide/"
    )

    // Xposed/LSPosed indicators
    private val XPOSED_PATHS = listOf(
        "/data/adb/lspd", "/data/adb/modules/zygisk_lsposed",
        "/data/adb/modules/riru_lsposed", "/data/data/de.robv.android.xposed.installer",
        "/system/framework/XposedBridge.jar", "/system/lib/libxposed_art.so",
        "/system/lib64/libxposed_art.so", "/system/xposed.prop"
    )

    // Frida detection (extended)
    private val FRIDA_PATHS = listOf(
        "/data/local/tmp/frida", "/data/local/tmp/frida-server",
        "/data/local/tmp/re.frida.server", "/data/local/tmp/.frida/",
        "/data/local/tmp/.frida-server", "/data/local/tmp/frida-agent.js",
        "/data/local/tmp/gadget.so", "/data/local/tmp/libfrida-gum.so",
        "/data/local/tmp/libfrida-gadget.so", "/data/app/*/lib/*/libfrida.so",
        "/system/lib/libfrida.so", "/system/lib64/libfrida.so",
        "/system/lib/libfrida-gadget.so", "/system/lib64/libfrida-gadget.so",
        "/system/bin/frida-server", "/system/xbin/frida-server",
        "/vendor/bin/frida-server", "/data/misc/frida/"
    )

    private val FRIDA_PORTS = listOf(27042, 27043, 27047, 8888, 9999)

    // Busybox paths
    private val BUSYBOX_PATHS = listOf(
        "/system/xbin/busybox", "/system/bin/busybox",
        "/vendor/bin/busybox", "/sbin/busybox", "/xbin/busybox",
        "/data/data/stericson.busybox/", "/data/data/com.jrummy.busybox.installer/"
    )

    data class DetectionResult(
        val isRooted: Boolean = false,
        val rootPaths: List<String> = emptyList(),
        val rootPackages: List<String> = emptyList(),
        val magiskIndicators: List<String> = emptyList(),
        val zygiskIndicators: List<String> = emptyList(),
        val lsposedIndicators: List<String> = emptyList(),
        val riruIndicators: List<String> = emptyList(),
        val shamikoIndicators: List<String> = emptyList(),
        val xposedIndicators: List<String> = emptyList(),
        val fridaIndicators: List<String> = emptyList(),
        val busyboxIndicators: List<String> = emptyList(),
        val suBehavior: String? = null,
        val dangerousProps: Map<String, String> = emptyMap(),
        val tamperIndicators: List<String> = emptyList(),
        val detectionMethods: List<String> = emptyList()
    )

    suspend fun detectAll(context: Context): DetectionResult = withContext(Dispatchers.IO) {
        val results = listOf(
            async { detectRootPaths() },
            async { detectRootPackages(context) },
            async { detectMagisk() },
            async { detectZygisk() },
            async { detectLSPosed(context) },
            async { detectRiru() },
            async { detectShamiko() },
            async { detectXposed() },
            async { detectFrida() },
            async { detectBusybox() },
            async { testSuBehavior() },
            async { checkDangerousProps() },
            async { checkTamperIndicators(context) },
            async { detectMagiskDenyList() }
        ).awaitAll()

        results.fold(DetectionResult()) { acc, result ->
            acc.combine(result)
        }.also {
            Log.d(TAG, "Final detection result: $it")
        }
    }

    private fun DetectionResult.combine(other: DetectionResult): DetectionResult {
        return DetectionResult(
            isRooted = this.isRooted || other.isRooted,
            rootPaths = (this.rootPaths + other.rootPaths).distinct(),
            rootPackages = (this.rootPackages + other.rootPackages).distinct(),
            magiskIndicators = (this.magiskIndicators + other.magiskIndicators).distinct(),
            zygiskIndicators = (this.zygiskIndicators + other.zygiskIndicators).distinct(),
            lsposedIndicators = (this.lsposedIndicators + other.lsposedIndicators).distinct(),
            riruIndicators = (this.riruIndicators + other.riruIndicators).distinct(),
            shamikoIndicators = (this.shamikoIndicators + other.shamikoIndicators).distinct(),
            xposedIndicators = (this.xposedIndicators + other.xposedIndicators).distinct(),
            fridaIndicators = (this.fridaIndicators + other.fridaIndicators).distinct(),
            busyboxIndicators = (this.busyboxIndicators + other.busyboxIndicators).distinct(),
            suBehavior = this.suBehavior ?: other.suBehavior,
            dangerousProps = this.dangerousProps + other.dangerousProps,
            tamperIndicators = (this.tamperIndicators + other.tamperIndicators).distinct(),
            detectionMethods = (this.detectionMethods + other.detectionMethods).distinct()
        )
    }

    private fun detectRootPaths(): DetectionResult {
        val foundPaths = ROOT_PATHS.filter { path ->
            val exists = if (path.contains("*")) {
                !globFiles(path).isNullOrEmpty()
            } else {
                try {
                    File(path).exists().also { exists ->
                        Log.d(TAG, "Root path $path: ${if (exists) "FOUND" else "clean"}")
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error accessing root path $path", e)
                    false
                }
            }
            exists
        }

        return if (foundPaths.isNotEmpty()) {
            DetectionResult(
                isRooted = true,
                rootPaths = foundPaths,
                detectionMethods = listOf("Root path detection")
            )
        } else {
            DetectionResult()
        }
    }

    private fun detectRootPackages(context: Context): DetectionResult {
        val foundPackages = mutableListOf<String>()
        val pm = context.packageManager

        // Check installed packages
        ROOT_PACKAGES.forEach { pkg ->
            try {
                pm.getPackageInfo(pkg, 0)
                foundPackages.add(pkg)
                Log.d(TAG, "Found root package via PackageManager: $pkg")
            } catch (e: PackageManager.NameNotFoundException) {
                Log.d(TAG, "Package $pkg not found via PackageManager")
            } catch (e: Exception) {
                Log.e(TAG, "Error checking package $pkg", e)
            }
        }

        // Additional check via pm list
        try {
            val process = Runtime.getRuntime().exec("pm list packages")
            val output = process.inputStream.bufferedReader().use { it.readText() }
            ROOT_PACKAGES.forEach { pkg ->
                if (output.contains("package:$pkg")) {
                    if (!foundPackages.contains(pkg)) {
                        foundPackages.add(pkg)
                        Log.d(TAG, "Found root package via pm list: $pkg")
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error executing pm list packages", e)
        }

        // Specific check for org.lsposed.manager via /proc
        val lsposedProcFindings = detectLSPosedProcesses()
        if (lsposedProcFindings.isNotEmpty() && !foundPackages.contains("org.lsposed.manager")) {
            foundPackages.add("org.lsposed.manager")
            Log.d(TAG, "Found org.lsposed.manager via /proc scan")
        }

        return if (foundPackages.isNotEmpty()) {
            DetectionResult(
                isRooted = true,
                rootPackages = foundPackages,
                detectionMethods = listOf("Root package detection")
            )
        } else {
            DetectionResult()
        }
    }

    private fun detectMagisk(): DetectionResult {
        val findings = mutableListOf<String>()

        // Check Magisk paths
        MAGISK_PATHS.forEach { path ->
            if (path.contains("*")) {
                globFiles(path).forEach { foundPath ->
                    findings.add("Magisk path found: $foundPath")
                    Log.d(TAG, "Found Magisk path: $foundPath")
                }
            } else {
                try {
                    if (File(path).exists()) {
                        findings.add("Magisk path found: $path")
                        Log.d(TAG, "Found Magisk path: $path")
                    } else {
                        Log.d(TAG, "Magisk path $path not found")
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error accessing Magisk path $path", e)
                }
            }
        }

        // Check Magisk command
        try {
            val process = Runtime.getRuntime().exec("magisk -v")
            val output = process.inputStream.bufferedReader().use { it.readText() }.trim()
            if (output.isNotEmpty()) {
                findings.add("Magisk version: $output")
                Log.d(TAG, "Found Magisk version: $output")
            }
        } catch (e: Exception) {
            Log.d(TAG, "Magisk command check failed")
        }

        // Check Magisk modules
        try {
            val modulesDir = File("/data/adb/modules")
            if (modulesDir.exists() && modulesDir.list()?.isNotEmpty() == true) {
                findings.add("Magisk modules detected: ${modulesDir.list()?.joinToString()}")
                Log.d(TAG, "Found Magisk modules: ${modulesDir.list()?.joinToString()}")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error checking Magisk modules", e)
        }

        return if (findings.isNotEmpty()) {
            DetectionResult(
                isRooted = true,
                magiskIndicators = findings,
                detectionMethods = listOf("Magisk detection")
            )
        } else {
            DetectionResult()
        }
    }

    private fun detectZygisk(): DetectionResult {
        val findings = mutableListOf<String>()

        // Check Zygisk paths
        ZYGISK_PATHS.forEach { path ->
            if (path.contains("*")) {
                globFiles(path).forEach { foundPath ->
                    findings.add("Zygisk trace found: $foundPath")
                    Log.d(TAG, "Found Zygisk trace: $foundPath")
                }
            } else {
                try {
                    if (File(path).exists()) {
                        findings.add("Zygisk trace found: $path")
                        Log.d(TAG, "Found Zygisk trace: $path")
                    } else {
                        Log.d(TAG, "Zygisk path $path not found")
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error accessing Zygisk path $path", e)
                }
            }
        }

        return if (findings.isNotEmpty()) {
            DetectionResult(
                isRooted = true,
                zygiskIndicators = findings,
                detectionMethods = listOf("Zygisk detection")
            )
        } else {
            DetectionResult()
        }
    }

    private fun detectLSPosed(context: Context): DetectionResult {
        val findings = mutableListOf<String>()

        // Check LSPosed paths
        LSPOSED_PATHS.forEach { path ->
            if (path.contains("*")) {
                globFiles(path).forEach { foundPath ->
                    findings.add("LSPosed path found: $foundPath")
                    Log.d(TAG, "Found LSPosed path: $foundPath")
                }
            } else {
                try {
                    if (File(path).exists()) {
                        findings.add("LSPosed path found: $path")
                        Log.d(TAG, "Found LSPosed path: $path")
                    } else {
                        Log.d(TAG, "LSPosed path $path not found")
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error accessing LSPosed path $path", e)
                    findings.add("Access denied to LSPosed path: $path")
                }
            }
        }

        // Check for LSPosed package explicitly
        try {
            context.packageManager.getPackageInfo("org.lsposed.manager", 0)
            findings.add("LSPosed package detected: org.lsposed.manager")
            Log.d(TAG, "Found LSPosed package: org.lsposed.manager")
        } catch (e: PackageManager.NameNotFoundException) {
            Log.d(TAG, "LSPosed package org.lsposed.manager not found via PackageManager")
        } catch (e: Exception) {
            Log.e(TAG, "Error checking LSPosed package", e)
        }

        // Check for LSPosed processes via /proc
        val procFindings = detectLSPosedProcesses()
        findings.addAll(procFindings)

        // Check for LSPosed processes via ps -A
        try {
            val process = Runtime.getRuntime().exec("ps -A")
            val output = process.inputStream.bufferedReader().use { it.readText() }
            if (output.contains("lsposed", ignoreCase = true) || output.contains("LSPosed")) {
                findings.add("LSPosed process running (ps -A)")
                Log.d(TAG, "Found LSPosed process via ps -A")
            } else {
                Log.d(TAG, "No LSPosed process found in ps -A output")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error checking LSPosed processes via ps -A", e)
        }

        return if (findings.isNotEmpty()) {
            DetectionResult(
                isRooted = true,
                lsposedIndicators = findings,
                detectionMethods = listOf("LSPosed detection")
            )
        } else {
            DetectionResult()
        }
    }

    private fun detectRiru(): DetectionResult {
        val findings = mutableListOf<String>()

        // Check Riru paths
        RIRU_PATHS.forEach { path ->
            if (path.contains("*")) {
                globFiles(path).forEach { foundPath ->
                    findings.add("Riru path found: $foundPath")
                    Log.d(TAG, "Found Riru path: $foundPath")
                }
            } else {
                try {
                    if (File(path).exists()) {
                        findings.add("R `_iru path found: $path")
                        Log.d(TAG, "Found Riru path: $path")
                    } else {
                        Log.d(TAG, "Riru path $path not found")
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error accessing Riru path $path", e)
                }
            }
        }

        return if (findings.isNotEmpty()) {
            DetectionResult(
                isRooted = true,
                riruIndicators = findings,
                detectionMethods = listOf("Riru detection")
            )
        } else {
            DetectionResult()
        }
    }

    private fun detectShamiko(): DetectionResult {
        val findings = mutableListOf<String>()

        // Check Shamiko paths
        SHAMIKO_PATHS.forEach { path ->
            if (path.contains("*")) {
                globFiles(path).forEach { foundPath ->
                    findings.add("Shamiko path found: $foundPath")
                    Log.d(TAG, "Found Shamiko path: $foundPath")
                }
            } else {
                try {
                    if (File(path).exists()) {
                        findings.add("Shamiko path found: $path")
                        Log.d(TAG, "Found Shamiko path: $path")
                    } else {
                        Log.d(TAG, "Shamiko path $path not found")
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error accessing Shamiko path $path", e)
                }
            }
        }

        return if (findings.isNotEmpty()) {
            DetectionResult(
                isRooted = true,
                shamikoIndicators = findings,
                detectionMethods = listOf("Shamiko detection")
            )
        } else {
            DetectionResult()
        }
    }

    private fun detectXposed(): DetectionResult {
        val findings = mutableListOf<String>()

        // Check Xposed paths
        XPOSED_PATHS.forEach { path ->
            if (path.contains("*")) {
                globFiles(path).forEach { foundPath ->
                    findings.add("Xposed path found: $foundPath")
                    Log.d(TAG, "Found Xposed path: $foundPath")
                }
            } else {
                try {
                    if (File(path).exists()) {
                        findings.add("Xposed path found: $path")
                        Log.d(TAG, "Found Xposed path: $path")
                    } else {
                        Log.d(TAG, "Xposed path $path not found")
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error accessing Xposed path $path", e)
                }
            }
        }

        // Check for Xposed/LSPosed processes
        try {
            val process = Runtime.getRuntime().exec("ps -A")
            val output = process.inputStream.bufferedReader().use { it.readText() }
            if (output.contains("lsposed", ignoreCase = true) ||
                output.contains("LSPosed") ||
                output.contains("edxp") ||
                output.contains("xposed")) {
                findings.add("Xposed/LSPosed process running (ps -A)")
                Log.d(TAG, "Found Xposed/LSPosed process via ps -A")
            } else {
                Log.d(TAG, "No Xposed/LSPosed process found in ps -A output")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error checking Xposed processes via ps -A", e)
        }

        return if (findings.isNotEmpty()) {
            DetectionResult(
                isRooted = true,
                xposedIndicators = findings,
                detectionMethods = listOf("Xposed detection")
            )
        } else {
            DetectionResult()
        }
    }

    private fun detectFrida(): DetectionResult {
        val findings = mutableListOf<String>()

        // Check Frida paths
        FRIDA_PATHS.forEach { path ->
            if (path.contains("*")) {
                globFiles(path).forEach { foundPath ->
                    findings.add("Frida file found: $foundPath")
                    Log.d(TAG, "Found Frida file: $foundPath")
                }
            } else {
                try {
                    if (File(path).exists()) {
                        findings.add("Frida file found: $path")
                        Log.d(TAG, "Found Frida file: $path")
                    } else {
                        Log.d(TAG, "Frida path $path not found")
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error accessing Frida path $path", e)
                }
            }
        }

        // Check Frida processes
        try {
            val process = Runtime.getRuntime().exec("ps -A")
            val output = process.inputStream.bufferedReader().use { it.readText() }
            if (output.contains("frida") || output.contains("gadget") || output.contains("fridaserver")) {
                findings.add("Frida process running")
                Log.d(TAG, "Found Frida process")
            } else {
                Log.d(TAG, "No Frida process found in ps -A output")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error checking Frida processes", e)
        }

        // Check Frida ports
        FRIDA_PORTS.forEach { port ->
            try {
                Socket().use { socket ->
                    socket.connect(InetSocketAddress("127.0.0.1", port), TIMEOUT_MS)
                    findings.add("Frida port open: $port")
                    Log.d(TAG, "Found open Frida port: $port")
                }
            } catch (e: Exception) {
                Log.d(TAG, "Frida port $port not open")
            }
        }

        return if (findings.isNotEmpty()) {
            DetectionResult(
                isRooted = true,
                fridaIndicators = findings,
                detectionMethods = listOf("Frida detection")
            )
        } else {
            DetectionResult()
        }
    }

    private fun detectBusybox(): DetectionResult {
        val findings = mutableListOf<String>()

        // Check Busybox paths
        BUSYBOX_PATHS.forEach { path ->
            if (path.contains("*")) {
                globFiles(path).forEach { foundPath ->
                    findings.add("Busybox path found: $foundPath")
                    Log.d(TAG, "Found Busybox path: $foundPath")
                }
            } else {
                try {
                    if (File(path).exists()) {
                        findings.add("Busybox path found: $path")
                        Log.d(TAG, "Found Busybox path: $path")
                    } else {
                        Log.d(TAG, "Busybox path $path not found")
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error accessing Busybox path $path", e)
                }
            }
        }

        // Check Busybox command
        try {
            val process = Runtime.getRuntime().exec("busybox --help")
            val output = process.inputStream.bufferedReader().use { it.readText() }.trim()
            if (output.isNotEmpty()) {
                findings.add("Busybox command detected")
                Log.d(TAG, "Found Busybox command")
            }
        } catch (e: Exception) {
            Log.d(TAG, "Busybox command check failed")
        }

        return if (findings.isNotEmpty()) {
            DetectionResult(
                isRooted = true,
                busyboxIndicators = findings,
                detectionMethods = listOf("Busybox detection")
            )
        } else {
            DetectionResult()
        }
    }

    private fun testSuBehavior(): DetectionResult {
        try {
            // Test 1: Simple su command
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
            val output = process.inputStream.bufferedReader().use { it.readText() }
            process.waitFor(TIMEOUT_MS.toLong(), TimeUnit.MILLISECONDS)

            if (output.contains("uid=0")) {
                Log.d(TAG, "SU access granted")
                return DetectionResult(
                    isRooted = true,
                    suBehavior = "SU access granted",
                    detectionMethods = listOf("SU command test")
                )
            }

            // Test 2: Check which su
            val whichProcess = Runtime.getRuntime().exec("which su")
            val whichOutput = whichProcess.inputStream.bufferedReader().use { it.readText() }.trim()
            whichProcess.waitFor(TIMEOUT_MS.toLong(), TimeUnit.MILLISECONDS)

            if (whichOutput.isNotEmpty()) {
                Log.d(TAG, "Found SU binary at $whichOutput")
                return DetectionResult(
                    isRooted = true,
                    suBehavior = "SU binary found at $whichOutput",
                    detectionMethods = listOf("SU binary detection")
                )
            }
        } catch (e: Exception) {
            Log.d(TAG, "SU check failed (normal on non-rooted devices)")
        }

        return DetectionResult()
    }

    private fun checkDangerousProps(): DetectionResult {
        val dangerousProps = mutableMapOf<String, String>()

        try {
            val buildTags = Build.TAGS
            if (buildTags != null && buildTags.contains("test-keys")) {
                dangerousProps["ro.build.tags"] = buildTags
                Log.d(TAG, "Found dangerous prop: ro.build.tags=$buildTags")
            }

            val props = listOf(
                "ro.debuggable", "ro.secure", "ro.build.type",
                "ro.build.selinux", "ro.boot.veritymode"
            )

            props.forEach { prop ->
                try {
                    val value = getProp(prop)
                    if (value != null) {
                        when (prop) {
                            "ro.debuggable" -> if (value == "1") dangerousProps[prop] = value
                            "ro.secure" -> if (value == "0") dangerousProps[prop] = value
                            "ro.build.type" -> if (value == "userdebug" || value == "eng") dangerousProps[prop] = value
                            "ro.boot.veritymode" -> if (value != "enforcing") dangerousProps[prop] = value
                        }
                        if (dangerousProps.containsKey(prop)) {
                            Log.d(TAG, "Found dangerous prop: $prop=$value")
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error checking prop $prop", e)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error checking dangerous props", e)
        }

        return if (dangerousProps.isNotEmpty()) {
            DetectionResult(
                isRooted = true,
                dangerousProps = dangerousProps,
                detectionMethods = listOf("Dangerous properties check")
            )
        } else {
            DetectionResult()
        }
    }

    private fun checkTamperIndicators(context: Context): DetectionResult {
        val indicators = mutableListOf<String>()

        // Check for modified libraries
        val nativeLibs = context.applicationInfo.nativeLibraryDir
        try {
            File(nativeLibs).listFiles()?.forEach { lib ->
                val modifiedTime = lib.lastModified()
                val currentTime = System.currentTimeMillis()
                if (currentTime - modifiedTime < TimeUnit.DAYS.toMillis(1)) {
                    indicators.add("Recently modified library: ${lib.name}")
                    Log.d(TAG, "Found recently modified library: ${lib.name}")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error checking native libraries", e)
        }

        return if (indicators.isNotEmpty()) {
            DetectionResult(
                isRooted = true,
                tamperIndicators = indicators,
                detectionMethods = listOf("Tamper detection")
            )
        } else {
            DetectionResult()
        }
    }

    private fun detectMagiskDenyList(): DetectionResult {
        val findings = mutableListOf<String>()
        try {
            val denyListFile = File("/data/adb/magisk/denylist")
            if (denyListFile.exists()) {
                val content = denyListFile.readText()
                if (content.contains("org.lsposed.manager")) {
                    findings.add("LSPosed in Magisk DenyList")
                    Log.d(TAG, "Found org.lsposed.manager in Magisk DenyList")
                }
                findings.add("Magisk DenyList detected")
                Log.d(TAG, "Found Magisk DenyList file")
            } else {
                Log.d(TAG, "Magisk DenyList file not found")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error checking Magisk DenyList", e)
        }
        return if (findings.isNotEmpty()) {
            DetectionResult(
                isRooted = true,
                magiskIndicators = findings,
                detectionMethods = listOf("Magisk DenyList detection")
            )
        } else {
            DetectionResult()
        }
    }

    private fun detectLSPosedProcesses(): List<String> {
        val findings = mutableListOf<String>()
        try {
            File("/proc").listFiles()?.forEach { file ->
                if (file.isDirectory && file.name.toIntOrNull() != null) {
                    try {
                        val cmdline = File(file, "cmdline").readText().trim()
                        if (cmdline.contains("org.lsposed.manager") || cmdline.contains("LSPosed")) {
                            findings.add("LSPosed process found: PID ${file.name}")
                            Log.d(TAG, "Found LSPosed process: PID ${file.name}, cmdline: $cmdline")
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Error reading /proc/${file.name}/cmdline", e)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error scanning /proc for LSPosed processes", e)
        }
        return findings
    }

    private fun getProp(property: String): String? {
        return try {
            val process = Runtime.getRuntime().exec("getprop $property")
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val value = reader.readLine()
            process.waitFor()
            value
        } catch (e: Exception) {
            Log.e(TAG, "Error getting prop $property", e)
            null
        }
    }

    private fun globFiles(pattern: String): List<String> {
        if (!pattern.contains('*')) {
            try {
                if (File(pattern).exists()) {
                    Log.d(TAG, "Non-wildcard path $pattern exists")
                    return listOf(pattern)
                } else {
                    Log.d(TAG, "Non-wildcard path $pattern does not exist")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error checking file $pattern", e)
            }
            return emptyList()
        }
        return try {
            val parts = pattern.split('/')
            val filename = parts.last()
            val parentPath = parts.dropLast(1).joinToString("/")
            val command = if (parentPath.isNotEmpty()) {
                "find $parentPath -name \"$filename\" 2>/dev/null"
            } else {
                "find / -name \"$filename\" 2>/dev/null"
            }
            val process = Runtime.getRuntime().exec(command)
            val output = process.inputStream.bufferedReader().use { it.readText() }
            output.lines().filter { it.isNotBlank() }.also {
                Log.d(TAG, "globFiles for $pattern returned: $it")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error globbing files for $pattern", e)
            emptyList()
        }
    }
}